if mods["boblogistics"] then
require("prototypes.Bobs-block")
end