data.raw.roboport["roboport"].fast_replaceable_group = "roboport"
data.raw.roboport["roboport"].next_upgrade = "bre-roboport-mk2"