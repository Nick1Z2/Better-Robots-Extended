require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipies")
require("prototypes.technologies")
